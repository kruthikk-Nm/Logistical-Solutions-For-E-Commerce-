import serial
import time
data = serial.Serial(
                'COM3',
                baudrate = 9600,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                bytesize=serial.EIGHTBITS,
                timeout=1 # must use when using data.readline()
                )

def Read_Data():
  while True:

    D = data.read(12)
    D = D.decode('UTF-8', 'ignore')
    if len(D.strip()) == 12:
      print(D)
      break
  
  return D
